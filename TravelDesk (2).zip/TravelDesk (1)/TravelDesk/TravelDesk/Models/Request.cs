﻿namespace TravelDesk.Models
{
    public class Request
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string ProjectName { get; set; }
        public string DepartmentName { get; set; }
        public string ReasonForTravelling { get; set; }
        public string TypeOfBooking { get; set; }
        public string DomesticFlightDetails { get; set; }
        public string InternationalFlightDetails { get; set; }
        public string HotelDetails { get; set; }
        public string MealPreferences { get; set; }
        public string Status { get; set; }
        public string ManagerComments { get; set; }
        public string AdminComments { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}

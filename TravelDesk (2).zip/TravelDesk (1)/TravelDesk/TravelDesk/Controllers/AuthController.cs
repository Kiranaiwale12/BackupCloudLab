﻿using Microsoft.AspNetCore.Mvc;
using TravelDesk.Services;
using TravelDesk.DTOs;
using Microsoft.AspNetCore.Cors;
using Microsoft.Extensions.Logging;

namespace TravelDesk.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowSpecificOrigin")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<AuthController> _logger;


        public AuthController(IAuthService authService, ILogger<AuthController> logger)
        {
            _authService = authService;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDTO loginDto)
        {
            try
            {
                var token = await _authService.LoginAsync(loginDto);

                if (token == null)
                {
                    _logger.LogWarning("Login failed for user: {Email}", loginDto.Email);
                    return Unauthorized(new
                    {
                        type = "https://tools.ietf.org/html/rfc9110#section-15.5.2",
                        title = "Unauthorized",
                        status = 401,
                        traceId = HttpContext.TraceIdentifier
                    });
                }

                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred.");
                return StatusCode(StatusCodes.Status500InternalServerError, new
                {
                    type = "https://tools.ietf.org/html/rfc9110#section-15.5.2",
                    title = "Internal Server Error",
                    status = 500,
                    traceId = HttpContext.TraceIdentifier
                });
            }
        }
    


    [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDTO registerDto)
        {
            try
            {
                // Registration logic here
                return Ok(new { message = "User registered successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "Internal server error occurred", error = ex.Message });
            }
        }

    }
}

use TravelDb;
ALTER TABLE Users
ADD CONSTRAINT DF_Users_CreatedBy DEFAULT (1) FOR CreatedBy;

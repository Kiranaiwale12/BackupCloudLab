﻿using Microsoft.AspNetCore.Mvc;
using TravelDesk.Services;
using TravelDesk.Models;

namespace TravelDesk.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RequestController : ControllerBase
    {
        private readonly IRequestService _requestService;

        public RequestController(IRequestService requestService)
        {
            _requestService = requestService;
        }

        [HttpGet]
        public async Task<IActionResult> GetRequests()
        {
            var requests = await _requestService.GetRequestsAsync();
            return Ok(requests);
        }

        [HttpPost]
        public async Task<IActionResult> AddRequest([FromBody] Request request)
        {
            await _requestService.AddRequestAsync(request);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRequest(int id, [FromBody] Request request)
        {
            await _requestService.UpdateRequestAsync(id, request);
            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRequest(int id)
        {
            await _requestService.DeleteRequestAsync(id);
            return Ok();
        }
    }
}

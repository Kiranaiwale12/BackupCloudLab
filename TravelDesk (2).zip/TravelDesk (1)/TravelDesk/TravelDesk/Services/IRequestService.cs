﻿using TravelDesk.Models;

namespace TravelDesk.Services
{
    public interface IRequestService
    {
        Task<IEnumerable<Request>> GetRequestsAsync();
        Task AddRequestAsync(Request request);
        Task UpdateRequestAsync(int id, Request request);
        Task DeleteRequestAsync(int id);
    }
}

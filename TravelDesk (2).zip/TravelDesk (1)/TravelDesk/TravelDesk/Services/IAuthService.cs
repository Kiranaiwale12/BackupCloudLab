﻿using TravelDesk.DTOs;

namespace TravelDesk.Services
{
    public interface IAuthService
    {
        Task<string> LoginAsync(LoginDTO loginDto);
        Task<string> RegisterAsync
        (RegisterDTO registerDto);
    }
}

﻿using TravelDesk.DTOs;
using TravelDesk.Models;
using TravelDesk.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BCrypt.Net;
namespace TravelDesk.Services
{
    public class AuthService : IAuthService
    {
        private readonly TravelAdminDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        public AuthService(TravelAdminDbContext context, ILogger<AuthService> logger, IConfiguration configuration)
        {
            _context = context;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger)); // Ensure logger is provided
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration)); // Ensure configuration is provided
        }

        public async Task<string> LoginAsync(LoginDTO loginDto)
        {
            _logger.LogInformation("Attempting to login user: {Email}", loginDto.Email);
            try
            {
                var user = await _context.Users.SingleOrDefaultAsync(u => u.Email == loginDto.Email);
                if (user == null || !BCrypt.Net.BCrypt.Verify(loginDto.Password, user.Password))
                    return null;

                var token = GenerateJwtToken(user);
                return token;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred during login.");
                throw new InvalidOperationException("Error occurred during login", ex);
            }
        }

        public async Task<string> RegisterAsync(RegisterDTO registerDto)
        {
            var hashedPassword = BCrypt.Net.BCrypt.HashPassword(registerDto.Password);
            var user = new User
            {
                Email = registerDto.Email,
                Password = hashedPassword,
                FirstName = registerDto.FirstName,
                LastName = registerDto.LastName,
                Role = registerDto.Role
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            var token = GenerateJwtToken(user);
            return token;
        }

        private string GenerateJwtToken(User user)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Issuer"],
                claims,
                expires: DateTime.Now.AddDays(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
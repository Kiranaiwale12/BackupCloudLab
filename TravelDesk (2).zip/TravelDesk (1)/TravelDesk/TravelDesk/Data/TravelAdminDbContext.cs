﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using TravelDesk.Models;

namespace TravelDesk.Data
{
    public class TravelAdminDbContext : DbContext
    {
        public TravelAdminDbContext(DbContextOptions<TravelAdminDbContext> options) : base(options) {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Request> Requests { get; set; }
        public DbSet<Booking> Bookings { get; set; }
    }
}

﻿using TravelDesk.Models;
using TravelDesk.Data;
using Microsoft.EntityFrameworkCore;

namespace TravelDesk.Services
{
    public class RequestService : IRequestService
    {
        private readonly TravelAdminDbContext _context;

        public RequestService(TravelAdminDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Request>> GetRequestsAsync()
        {
            return await _context.Requests.ToListAsync();
        }

        public async Task AddRequestAsync(Request request)
        {
            _context.Requests.Add(request);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateRequestAsync(int id, Request request)
        {
            var existingRequest = await _context.Requests.FindAsync(id);
            if (existingRequest != null)
            {
                existingRequest.EmployeeId = request.EmployeeId;
                existingRequest.EmployeeName = request.EmployeeName;
                existingRequest.ProjectName = request.ProjectName;
                existingRequest.DepartmentName = request.DepartmentName;
                existingRequest.ReasonForTravelling = request.ReasonForTravelling;
                existingRequest.TypeOfBooking = request.TypeOfBooking;
                existingRequest.DomesticFlightDetails = request.DomesticFlightDetails;
                existingRequest.InternationalFlightDetails = request.InternationalFlightDetails;
                existingRequest.HotelDetails = request.HotelDetails;
                existingRequest.MealPreferences = request.MealPreferences;
                existingRequest.Status = request.Status;
                existingRequest.ManagerComments = request.ManagerComments;
                existingRequest.AdminComments = request.AdminComments;

                await _context.SaveChangesAsync();
            }
        }

        public async Task DeleteRequestAsync(int id)
        {
            var request = await _context.Requests.FindAsync(id);
            if (request != null)
            {
                _context.Requests.Remove(request);
                await _context.SaveChangesAsync();
            }
        }
    }
}

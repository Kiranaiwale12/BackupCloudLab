﻿namespace TravelDesk.DTOs
{
    public class RequestDTO
    {

        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string ProjectName { get; set; }
        public string DepartmentName { get; set; }
        public string ReasonForTravelling { get; set; }
        public string TypeOfBooking { get; set; }
        public string DomesticFlightDetails { get; set; }
        public string InternationalFlightDetails { get; set; }
        public string HotelDetails { get; set; }
        public string MealPreferences { get; set; }
        public RequestDTO()
        {
            ProjectName = ""; // Initialize with a default value
            ReasonForTravelling = ""; // Initialize with a default value
        }
    }
}

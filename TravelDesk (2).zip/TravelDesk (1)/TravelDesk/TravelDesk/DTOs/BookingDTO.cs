﻿namespace TravelDesk.DTOs
{
    public class BookingDTO
    {
        public int RequestId { get; set; }
        public string BookingDetails { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
    }
}

﻿using TravelDesk.Models;
using TravelDesk.Data;
using Microsoft.EntityFrameworkCore;

namespace TravelDesk.Services
{
    public class BookingService : IBookingService
    {
        private readonly TravelAdminDbContext _context;

        public BookingService(TravelAdminDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Booking>> GetBookingsAsync()
        {
            return await _context.Bookings.ToListAsync();
        }

        public async Task AddBookingAsync(Booking booking)
        {
            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateBookingAsync(int id, Booking booking)
        {
            var existingBooking = await _context.Bookings.FindAsync(id);
            if (existingBooking != null)
            {
                existingBooking.RequestId = booking.RequestId;
                existingBooking.BookingDetails = booking.BookingDetails;
                existingBooking.Status = booking.Status;
                existingBooking.Comments = booking.Comments;

                await _context.SaveChangesAsync();
            }
        }

        public async Task DeleteBookingAsync(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null)
            {
                _context.Bookings.Remove(booking);
                await _context.SaveChangesAsync();
            }
        }
    }
}

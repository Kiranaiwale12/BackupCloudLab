﻿using Microsoft.AspNetCore.Identity;
using TravelDesk.DTOs;
using TravelDesk.Models;

namespace TravelDesk.Services
{
    public interface IUserService
    {
        Task<IEnumerable<User>> GetUsersAsync();
        Task AddUserAsync(User user);
        Task UpdateUserAsync(int id, User user);
        Task DeleteUserAsync(int id);
       // Task<IdentityResult> RegisterUserAsync(RegisterDTO registerDto);
    }
}
